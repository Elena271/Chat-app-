import { auth } from './firebase-config.js';
import {
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword
} from 'https://www.gstatic.com/firebasejs/9.6.10/firebase-auth.js';

window.registerUser = function() {
  const email = document.getElementById('regEmail').value;
  const password = document.getElementById('regPassword').value;
  
  createUserWithEmailAndPassword(auth, email, password)
    .then(() => alert('Registered!'))
    .catch(error => alert(error.message));
};

window.loginUser = function() {
  const email = document.getElementById('loginEmail').value;
  const password = document.getElementById('loginPassword').value;
  
  signInWithEmailAndPassword(auth, email, password)
    .then(() => alert('Login successful!'))
    .catch(error => alert(error.message));
};
