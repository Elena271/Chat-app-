// firebase-config.js
import { initializeApp } from "https://www.gstatic.com/firebasejs/9.6.10/firebase-app.js";
import { getAuth } from "https://www.gstatic.com/firebasejs/9.6.10/firebase-auth.js";

const firebaseConfig = {
  apiKey: "AIzaSyCUHObvq1QM1t3XNeOu6Q0LDwzKipk4YsM",
  authDomain: "my-website-1f37b.firebaseapp.com",
  projectId: "my-website-1f37b",
  storageBucket: "my-website-1f37b.appspot.com",
  messagingSenderId: "1090751027904",
  appId: "1:1090751027904:web:5321501bd7786caf2eab25",
  measurementId: "G-9BBQBDTNLJ"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);

export { auth };